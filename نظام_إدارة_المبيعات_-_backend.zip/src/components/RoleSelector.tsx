import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Shield, User } from "lucide-react";

export function RoleSelector() {
  const [selectedRole, setSelectedRole] = useState<"admin" | "employee" | null>(null);
  const assignRole = useMutation(api.userRoles.assignRole);

  const handleRoleSelection = async (role: "admin" | "employee") => {
    try {
      const assignedRole = await assignRole({ role });
      
      if (assignedRole === "admin") {
        toast.success("تم تعيينك كمدير للنظام!");
      } else {
        toast.success("تم تعيينك كموظف مبيعات!");
      }
      
      window.location.reload();
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ";
      toast.error(message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            مرحباً بك في نظام إدارة المبيعات
          </h1>
          <p className="text-gray-600">اختر دورك في النظام للمتابعة</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* بطاقة المدير */}
          <button
            onClick={() => handleRoleSelection("admin")}
            className="bg-white rounded-2xl p-8 shadow-lg border-2 border-gray-200 hover:border-blue-500 hover:shadow-xl transition-all group"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">مدير النظام</h3>
              <p className="text-gray-600 text-sm mb-4">
                عرض جميع المبيعات والإحصائيات الشاملة
              </p>
              <ul className="text-right text-sm text-gray-600 space-y-2">
                <li>✓ متابعة جميع الموظفين</li>
                <li>✓ عرض كل المبيعات</li>
                <li>✓ تقارير شاملة</li>
                <li>✓ إحصائيات متقدمة</li>
              </ul>
            </div>
          </button>

          {/* بطاقة الموظف */}
          <button
            onClick={() => handleRoleSelection("employee")}
            className="bg-white rounded-2xl p-8 shadow-lg border-2 border-gray-200 hover:border-green-500 hover:shadow-xl transition-all group"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <User className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">موظف مبيعات</h3>
              <p className="text-gray-600 text-sm mb-4">
                تسجيل المبيعات اليومية ومتابعة أدائك
              </p>
              <ul className="text-right text-sm text-gray-600 space-y-2">
                <li>✓ تسجيل التذاكر</li>
                <li>✓ عرض مبيعاتك</li>
                <li>✓ متابعة أدائك</li>
                <li>✓ إحصائياتك الشخصية</li>
              </ul>
            </div>
          </button>
        </div>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>💡 ملاحظة: أول مستخدم يسجل في النظام يصبح مدير تلقائياً</p>
        </div>
      </div>
    </div>
  );
}
