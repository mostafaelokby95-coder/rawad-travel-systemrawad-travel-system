import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { TrendingUp, DollarSign, ShoppingCart, Plane, Trash2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { useState } from "react";

export function Dashboard() {
  const stats = useQuery(api.sales.getStats);
  const last7Days = useQuery(api.sales.getLast7Days);
  const clearAllSales = useMutation(api.sales.clearAllSales);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  if (stats === undefined || last7Days === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <p className="text-gray-500">لا توجد بيانات متاحة</p>
      </div>
    );
  }

  const handleClearAll = async () => {
    try {
      const result = await clearAllSales();
      toast.success(`تم مسح ${result.deletedCount} عملية بيع بنجاح! 🗑️`);
      setShowConfirmDialog(false);
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء المسح";
      toast.error(message);
    }
  };

  const statCards = [
    {
      title: stats.isAdmin ? "إجمالي المبيعات" : "مبيعاتي الإجمالية",
      value: `${stats.totalSales.toLocaleString('ar-EG')} جنيه`,
      icon: DollarSign,
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      iconColor: "text-blue-600",
    },
    {
      title: "مبيعات اليوم",
      value: `${stats.todayTotal.toLocaleString('ar-EG')} جنيه`,
      icon: TrendingUp,
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50",
      iconColor: "text-green-600",
    },
    {
      title: "مبيعات الشهر",
      value: `${stats.monthTotal.toLocaleString('ar-EG')} جنيه`,
      icon: Plane,
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
      iconColor: "text-purple-600",
    },
    {
      title: "عدد التذاكر",
      value: stats.salesCount.toString(),
      icon: ShoppingCart,
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-50",
      iconColor: "text-orange-600",
    },
  ];

  return (
    <div className="space-y-8">
      {/* زر مسح جميع البيانات (للمدير فقط) */}
      {stats.isAdmin && stats.salesCount > 0 && (
        <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-red-900 mb-1">مسح جميع البيانات</h3>
              <p className="text-sm text-red-700">حذف جميع عمليات البيع بشكل نهائي (لا يمكن التراجع)</p>
            </div>
            <button
              onClick={() => setShowConfirmDialog(true)}
              className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-all shadow-lg hover:shadow-xl"
            >
              <Trash2 className="w-5 h-5" />
              <span>مسح الكل</span>
            </button>
          </div>
        </div>
      )}

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-2">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={`${card.bgColor} p-3 rounded-xl`}>
                <card.icon className={`w-6 h-6 ${card.iconColor}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* العمولات */}
      {stats.totalCommission > 0 && (
        <div className="bg-gradient-to-l from-green-50 to-transparent rounded-2xl p-6 border-2 border-green-200">
          <h3 className="text-lg font-bold text-gray-900 mb-2">إجمالي العمولات</h3>
          <p className="text-3xl font-bold text-green-600">
            {stats.totalCommission.toLocaleString('ar-EG')} جنيه
          </p>
        </div>
      )}

      {/* الرسم البياني */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-bold text-gray-900 mb-6">
          {stats.isAdmin ? "مبيعات الشركة - آخر 7 أيام" : "مبيعاتي - آخر 7 أيام"}
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={last7Days}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
              }}
              formatter={(value) => [`${(value || 0).toLocaleString('ar-EG')} جنيه`, 'المبيعات']}
            />
            <Bar dataKey="total" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
            <defs>
              <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#2563eb" />
              </linearGradient>
            </defs>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* أفضل الموظفين (للمدير فقط) */}
      {stats.isAdmin && stats.topEmployees.length > 0 && (
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-6">أفضل الموظفين</h3>
          <div className="space-y-4">
            {stats.topEmployees.map((employee, index) => (
              <div
                key={employee.employeeId}
                className="flex items-center justify-between p-4 bg-gradient-to-l from-blue-50 to-transparent rounded-xl hover:from-blue-100 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{employee.employeeName}</p>
                    <p className="text-sm text-gray-600">{employee.salesCount} تذكرة</p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="text-xl font-bold text-blue-600">
                    {employee.totalSales.toLocaleString('ar-EG')} جنيه
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* نافذة التأكيد */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
            <div className="text-center mb-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <Trash2 className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">تأكيد المسح</h3>
              <p className="text-gray-600">
                هل أنت متأكد من حذف <span className="font-bold text-red-600">{stats.salesCount}</span> عملية بيع؟
              </p>
              <p className="text-sm text-red-600 mt-2 font-semibold">
                ⚠️ هذا الإجراء لا يمكن التراجع عنه!
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirmDialog(false)}
                className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded-xl hover:bg-gray-300 transition-all"
              >
                إلغاء
              </button>
              <button
                onClick={handleClearAll}
                className="flex-1 px-6 py-3 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-all shadow-lg hover:shadow-xl"
              >
                نعم، احذف الكل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
