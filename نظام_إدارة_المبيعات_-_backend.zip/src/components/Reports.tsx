import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import {
  Calendar,
  TrendingUp,
  TrendingDown,
  Download,
  BarChart3,
  PieChart,
  Users,
  DollarSign,
} from "lucide-react";
import { Id } from "../../convex/_generated/dataModel";

export function Reports() {
  const [reportType, setReportType] = useState<"detailed" | "comparison" | "employees">("detailed");
  const [period, setPeriod] = useState<"today" | "week" | "month" | "year" | "custom">("month");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState<Id<"users"> | undefined>();

  const userRole = useQuery(api.userRoles.getMyRole);
  const isAdmin = userRole === "admin";

  // حساب التواريخ
  const getDateRange = () => {
    const now = new Date();
    const end = now.getTime();
    let start = end;

    switch (period) {
      case "today":
        start = new Date(now.setHours(0, 0, 0, 0)).getTime();
        break;
      case "week":
        start = end - 7 * 24 * 60 * 60 * 1000;
        break;
      case "month":
        start = end - 30 * 24 * 60 * 60 * 1000;
        break;
      case "year":
        start = end - 365 * 24 * 60 * 60 * 1000;
        break;
      case "custom":
        if (customStart && customEnd) {
          start = new Date(customStart).getTime();
          return { start, end: new Date(customEnd).getTime() };
        }
        break;
    }

    return { start, end };
  };

  const { start, end } = getDateRange();

  const detailedReport = useQuery(
    api.reports.getDetailedReport,
    reportType === "detailed" ? { startDate: start, endDate: end, employeeId: selectedEmployee } : "skip"
  );

  const employeesPerformance = useQuery(
    api.reports.getEmployeesPerformance,
    reportType === "employees" && isAdmin ? { startDate: start, endDate: end } : "skip"
  );

  // دالة تصدير إلى CSV
  const exportToCSV = () => {
    if (!detailedReport) return;

    const csvContent = [
      ["التاريخ", "اسم العميل", "الوجهة", "المبلغ", "العمولة", "الموظف"],
      ...detailedReport.sales.map((sale) => [
        new Date(sale.saleDate).toLocaleDateString("ar-EG"),
        sale.customerName,
        sale.destination || "-",
        sale.amount.toString(),
        (sale.commission || 0).toString(),
        sale.employeeName,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `تقرير_المبيعات_${new Date().toLocaleDateString("ar-EG")}.csv`;
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">التقارير والتحليلات</h2>
          <p className="text-gray-600 mt-1">تحليل شامل لأداء المبيعات</p>
        </div>
        <button
          onClick={exportToCSV}
          disabled={!detailedReport}
          className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download className="w-5 h-5" />
          <span>تصدير Excel</span>
        </button>
      </div>

      {/* نوع التقرير */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setReportType("detailed")}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              reportType === "detailed"
                ? "bg-blue-600 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            <span>تقرير مفصل</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setReportType("employees")}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
                reportType === "employees"
                  ? "bg-blue-600 text-white shadow-lg"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Users className="w-5 h-5" />
              <span>أداء الموظفين</span>
            </button>
          )}
        </div>
      </div>

      {/* اختيار الفترة */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-blue-600" />
          <span>اختر الفترة الزمنية</span>
        </h3>

        <div className="flex flex-wrap gap-3 mb-4">
          {[
            { value: "today", label: "اليوم" },
            { value: "week", label: "آخر أسبوع" },
            { value: "month", label: "آخر شهر" },
            { value: "year", label: "آخر سنة" },
            { value: "custom", label: "فترة مخصصة" },
          ].map((p) => (
            <button
              key={p.value}
              onClick={() => setPeriod(p.value as any)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                period === p.value
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {period === "custom" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">من تاريخ</label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">إلى تاريخ</label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
              />
            </div>
          </div>
        )}
      </div>

      {/* التقرير المفصل */}
      {reportType === "detailed" && detailedReport && (
        <div className="space-y-6">
          {/* ملخص الإحصائيات */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg p-6 text-white">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="w-8 h-8 opacity-80" />
              </div>
              <p className="text-sm opacity-90 mb-1">إجمالي المبيعات</p>
              <p className="text-3xl font-bold">{detailedReport.summary.totalSales.toLocaleString()} ج.م</p>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-lg p-6 text-white">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-8 h-8 opacity-80" />
              </div>
              <p className="text-sm opacity-90 mb-1">إجمالي العمولات</p>
              <p className="text-3xl font-bold">{detailedReport.summary.totalCommission.toLocaleString()} ج.م</p>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-lg p-6 text-white">
              <div className="flex items-center justify-between mb-2">
                <BarChart3 className="w-8 h-8 opacity-80" />
              </div>
              <p className="text-sm opacity-90 mb-1">عدد التذاكر</p>
              <p className="text-3xl font-bold">{detailedReport.summary.salesCount}</p>
            </div>

            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl shadow-lg p-6 text-white">
              <div className="flex items-center justify-between mb-2">
                <PieChart className="w-8 h-8 opacity-80" />
              </div>
              <p className="text-sm opacity-90 mb-1">متوسط البيع</p>
              <p className="text-3xl font-bold">{Math.round(detailedReport.summary.averageSale).toLocaleString()} ج.م</p>
            </div>
          </div>

          {/* أفضل الوجهات */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">أفضل الوجهات</h3>
            <div className="space-y-3">
              {detailedReport.topDestinations.map((dest, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{dest.name}</p>
                      <p className="text-sm text-gray-600">{dest.count} تذكرة</p>
                    </div>
                  </div>
                  <p className="text-lg font-bold text-blue-600">{dest.total.toLocaleString()} ج.م</p>
                </div>
              ))}
            </div>
          </div>

          {/* أفضل شركات الطيران */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">أفضل شركات الطيران</h3>
            <div className="space-y-3">
              {detailedReport.topAirlines.map((airline, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{airline.name}</p>
                      <p className="text-sm text-gray-600">{airline.count} تذكرة</p>
                    </div>
                  </div>
                  <p className="text-lg font-bold text-green-600">{airline.total.toLocaleString()} ج.م</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* تقرير أداء الموظفين */}
      {reportType === "employees" && employeesPerformance && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">أداء الموظفين</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-b from-gray-50 to-gray-100">
                <tr>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase">الموظف</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase">عدد التذاكر</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase">إجمالي المبيعات</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase">العمولات</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700 uppercase">متوسط البيع</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {employeesPerformance.map((emp, index) => (
                  <tr key={index} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{emp.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{emp.count}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-blue-600">
                      {emp.total.toLocaleString()} ج.م
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-green-600">
                      {emp.commission.toLocaleString()} ج.م
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{Math.round(emp.average).toLocaleString()} ج.م</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
