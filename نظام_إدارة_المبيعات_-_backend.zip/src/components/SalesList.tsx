import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Calendar, User, Plane, MapPin, Edit, Trash2, Search } from "lucide-react";
import { useState } from "react";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

export function SalesList() {
  const allSales = useQuery(api.sales.listAll);
  const mySales = useQuery(api.sales.listMySales);
  const isAdmin = useQuery(api.userRoles.isAdmin);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [editingSale, setEditingSale] = useState<Id<"sales"> | null>(null);
  const [editForm, setEditForm] = useState({
    ticketNumber: "",
    destination: "",
    departureDate: "",
    returnDate: "",
    airline: "",
    amount: "",
    commission: "",
    description: "",
    notes: "",
  });

  const updateSale = useMutation(api.sales.update);
  const removeSale = useMutation(api.sales.remove);
  const searchResults = useQuery(
    api.sales.search,
    searchTerm.length > 0 ? { searchTerm } : "skip"
  );

  if (allSales === undefined || mySales === undefined || isAdmin === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const handleEdit = (sale: any) => {
    setEditingSale(sale._id);
    setEditForm({
      ticketNumber: sale.ticketNumber || "",
      destination: sale.destination || "",
      departureDate: sale.departureDate || "",
      returnDate: sale.returnDate || "",
      airline: sale.airline || "",
      amount: sale.amount.toString(),
      commission: sale.commission?.toString() || "",
      description: sale.description || "",
      notes: sale.notes || "",
    });
  };

  const handleUpdate = async (saleId: Id<"sales">) => {
    try {
      await updateSale({
        saleId,
        ticketNumber: editForm.ticketNumber || undefined,
        destination: editForm.destination || undefined,
        departureDate: editForm.departureDate || undefined,
        returnDate: editForm.returnDate || undefined,
        airline: editForm.airline || undefined,
        amount: editForm.amount ? parseFloat(editForm.amount) : undefined,
        commission: editForm.commission ? parseFloat(editForm.commission) : undefined,
        description: editForm.description || undefined,
        notes: editForm.notes || undefined,
      });
      toast.success("تم تحديث المعاملة بنجاح!");
      setEditingSale(null);
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء التحديث";
      toast.error(message);
    }
  };

  const handleDelete = async (saleId: Id<"sales">) => {
    if (!confirm("هل أنت متأكد من حذف هذه المعاملة؟")) return;
    
    try {
      await removeSale({ saleId });
      toast.success("تم حذف المعاملة بنجاح!");
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء الحذف";
      toast.error(message);
    }
  };

  const displaySales = searchTerm.length > 0 ? searchResults : mySales;

  const renderSalesList = (sales: typeof mySales, title: string, showAll: boolean = false) => (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
      <h3 className="text-xl font-bold text-gray-900 mb-6">{title}</h3>
      
      {sales.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
            <Plane className="w-10 h-10 text-gray-400" />
          </div>
          <p className="text-gray-500 text-lg">لا توجد معاملات مسجلة بعد</p>
          <p className="text-gray-400 text-sm mt-2">ابدأ بتسجيل أول معاملة!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {sales.map((sale) => (
            <div
              key={sale._id}
              className="p-5 bg-gradient-to-l from-blue-50 to-transparent rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all"
            >
              {editingSale === sale._id ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input
                      type="text"
                      value={editForm.ticketNumber}
                      onChange={(e) => setEditForm({ ...editForm, ticketNumber: e.target.value })}
                      placeholder="رقم الحجز"
                      className="px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-blue-500 outline-none"
                    />
                    <input
                      type="text"
                      value={editForm.destination}
                      onChange={(e) => setEditForm({ ...editForm, destination: e.target.value })}
                      placeholder="الوجهة"
                      className="px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-blue-500 outline-none"
                    />
                    <input
                      type="text"
                      value={editForm.airline}
                      onChange={(e) => setEditForm({ ...editForm, airline: e.target.value })}
                      placeholder="شركة الطيران"
                      className="px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-blue-500 outline-none"
                    />
                    <input
                      type="number"
                      value={editForm.amount}
                      onChange={(e) => setEditForm({ ...editForm, amount: e.target.value })}
                      placeholder="المبلغ"
                      className="px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-blue-500 outline-none"
                    />
                    <input
                      type="number"
                      value={editForm.commission}
                      onChange={(e) => setEditForm({ ...editForm, commission: e.target.value })}
                      placeholder="العمولة"
                      className="px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-blue-500 outline-none"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdate(sale._id)}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                    >
                      حفظ
                    </button>
                    <button
                      onClick={() => setEditingSale(null)}
                      className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Plane className="w-5 h-5 text-blue-600" />
                        <h4 className="font-bold text-gray-900 text-lg">
                          {sale.customerName}
                        </h4>
                      </div>
                      {sale.destination && (
                        <div className="flex items-center gap-2 text-gray-600 mb-1">
                          <MapPin className="w-4 h-4" />
                          <span className="font-semibold">{sale.destination}</span>
                        </div>
                      )}
                      <p className="text-sm text-gray-600">
                        {sale.airline && `${sale.airline} • `}رقم الحجز: {sale.ticketNumber}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="text-2xl font-bold text-blue-600">
                        {sale.amount.toLocaleString('ar-EG')} جنيه
                      </p>
                      {sale.commission && (
                        <p className="text-sm text-green-600 font-semibold">
                          عمولة: {sale.commission.toLocaleString('ar-EG')} جنيه
                        </p>
                      )}
                    </div>
                  </div>

                  {sale.description && (
                    <div className="bg-gray-50 rounded-lg p-3 mb-3">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">الوصف:</span> {sale.description}
                      </p>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-3">
                    {showAll && (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>{sale.employeeName}</span>
                      </div>
                    )}
                    {sale.departureDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>
                          المغادرة: {new Date(sale.departureDate).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                    )}
                    {sale.returnDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>
                          العودة: {new Date(sale.returnDate).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>
                        تاريخ البيع: {new Date(sale.saleDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  </div>

                  {sale.notes && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg mb-3">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">ملاحظات:</span> {sale.notes}
                      </p>
                    </div>
                  )}

                  <div className="flex gap-2 pt-3 border-t border-gray-200">
                    <button
                      onClick={() => handleEdit(sale)}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium"
                    >
                      <Edit className="w-4 h-4" />
                      تعديل
                    </button>
                    <button
                      onClick={() => handleDelete(sale._id)}
                      className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
                    >
                      <Trash2 className="w-4 h-4" />
                      حذف
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-8">
      {/* شريط البحث */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث عن معاملة (اسم العميل، رقم الحجز، الوجهة، شركة الطيران...)"
            className="w-full pr-10 pl-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
          />
        </div>
      </div>

      {renderSalesList(displaySales || [], searchTerm ? "نتائج البحث" : "معاملاتي", false)}
      {isAdmin && !searchTerm && allSales.length > 0 && renderSalesList(allSales, "جميع المعاملات (عرض المدير)", true)}
    </div>
  );
}
