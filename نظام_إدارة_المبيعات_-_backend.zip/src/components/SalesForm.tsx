import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Plus, Search, X, Plane, Calendar } from "lucide-react";
import { Id } from "../../convex/_generated/dataModel";

export function SalesForm() {
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<{
    id: Id<"customers">;
    name: string;
  } | null>(null);

  // بيانات التذكرة (فقط السعر ورقم الحجز إلزاميين)
  const [ticketNumber, setTicketNumber] = useState("");
  const [destination, setDestination] = useState("");
  const [departureDate, setDepartureDate] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [airline, setAirline] = useState("");
  const [amount, setAmount] = useState("");
  const [commission, setCommission] = useState("");
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [saleDate, setSaleDate] = useState(new Date().toISOString().split('T')[0]);

  // بيانات العميل الجديد
  const [newCustomerName, setNewCustomerName] = useState("");
  const [newCustomerPhone, setNewCustomerPhone] = useState("");
  const [newCustomerEmail, setNewCustomerEmail] = useState("");
  const [newCustomerPassport, setNewCustomerPassport] = useState("");

  const createSale = useMutation(api.sales.create);
  const createCustomer = useMutation(api.customers.create);
  const searchCustomers = useQuery(
    api.customers.search,
    searchTerm.length > 0 ? { searchTerm } : "skip"
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!ticketNumber.trim()) {
      toast.error("يرجى إدخال رقم الحجز");
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      toast.error("يرجى إدخال مبلغ صحيح");
      return;
    }

    try {
      const saleDateTimestamp = new Date(saleDate).getTime();
      
      await createSale({
        customerId: selectedCustomer?.id,
        customerName: selectedCustomer?.name,
        ticketNumber: ticketNumber.trim(),
        destination: destination.trim() || undefined,
        departureDate: departureDate || undefined,
        returnDate: returnDate || undefined,
        airline: airline.trim() || undefined,
        amount: parseFloat(amount),
        commission: commission ? parseFloat(commission) : undefined,
        description: description.trim() || undefined,
        notes: notes.trim() || undefined,
        saleDate: saleDateTimestamp,
      });

      toast.success("تم تسجيل المعاملة بنجاح! ✅");
      
      // إعادة تعيين النموذج
      setTicketNumber("");
      setDestination("");
      setDepartureDate("");
      setReturnDate("");
      setAirline("");
      setAmount("");
      setCommission("");
      setDescription("");
      setNotes("");
      setSaleDate(new Date().toISOString().split('T')[0]);
      setSelectedCustomer(null);
      setSearchTerm("");
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء تسجيل المعاملة";
      toast.error(message);
    }
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newCustomerName.trim()) {
      toast.error("يرجى إدخال اسم العميل");
      return;
    }

    try {
      const customerId = await createCustomer({
        name: newCustomerName.trim(),
        phone: newCustomerPhone.trim() || undefined,
        email: newCustomerEmail.trim() || undefined,
        passport: newCustomerPassport.trim() || undefined,
      });

      toast.success("تم إضافة العميل بنجاح!");
      
      setSelectedCustomer({
        id: customerId,
        name: newCustomerName.trim(),
      });
      
      setShowCustomerForm(false);
      setNewCustomerName("");
      setNewCustomerPhone("");
      setNewCustomerEmail("");
      setNewCustomerPassport("");
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء إضافة العميل";
      toast.error(message);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-blue-100 rounded-xl">
          <Plane className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">تسجيل معاملة جديدة</h2>
          <p className="text-sm text-gray-500">فقط رقم الحجز والسعر إلزاميين</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* تاريخ البيع */}
        <div className="bg-blue-50 p-4 rounded-xl border-2 border-blue-200">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline ml-2" />
            تاريخ المعاملة
          </label>
          <input
            type="date"
            value={saleDate}
            onChange={(e) => setSaleDate(e.target.value)}
            required
            className="w-full px-4 py-3 rounded-xl border-2 border-blue-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all bg-white"
          />
        </div>

        {/* الحقول الإلزامية */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              رقم الحجز / التذكرة <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={ticketNumber}
              onChange={(e) => setTicketNumber(e.target.value)}
              placeholder="مثال: TK12345"
              required
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              المبلغ (جنيه) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              step="0.01"
              min="0"
              required
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
            />
          </div>
        </div>

        {/* الحقول الاختيارية */}
        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">معلومات إضافية (اختيارية)</h3>
          
          {/* اختيار العميل */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              العميل
            </label>
            
            {selectedCustomer ? (
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
                <span className="font-semibold text-blue-900">{selectedCustomer.name}</span>
                <button
                  type="button"
                  onClick={() => setSelectedCustomer(null)}
                  className="text-blue-600 hover:text-blue-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="ابحث عن عميل..."
                    className="w-full pr-10 pl-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                  />
                </div>

                {searchCustomers && searchCustomers.length > 0 && (
                  <div className="max-h-48 overflow-y-auto space-y-2 p-2 bg-gray-50 rounded-xl">
                    {searchCustomers.map((customer) => (
                      <button
                        key={customer._id}
                        type="button"
                        onClick={() => {
                          setSelectedCustomer({ id: customer._id, name: customer.name });
                          setSearchTerm("");
                        }}
                        className="w-full text-right p-3 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-blue-200"
                      >
                        <p className="font-semibold text-gray-900">{customer.name}</p>
                        {customer.phone && (
                          <p className="text-sm text-gray-600">{customer.phone}</p>
                        )}
                      </button>
                    ))}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setShowCustomerForm(true)}
                  className="w-full flex items-center justify-center gap-2 p-3 border-2 border-dashed border-gray-300 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all text-gray-600 hover:text-blue-600"
                >
                  <Plus className="w-5 h-5" />
                  <span>إضافة عميل جديد</span>
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                الوجهة
              </label>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="مثال: دبي - الإمارات"
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                شركة الطيران
              </label>
              <input
                type="text"
                value={airline}
                onChange={(e) => setAirline(e.target.value)}
                placeholder="مثال: مصر للطيران"
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                تاريخ المغادرة
              </label>
              <input
                type="date"
                value={departureDate}
                onChange={(e) => setDepartureDate(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                تاريخ العودة
              </label>
              <input
                type="date"
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                العمولة
              </label>
              <input
                type="number"
                value={commission}
                onChange={(e) => setCommission(e.target.value)}
                placeholder="0.00"
                step="0.01"
                min="0"
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>
          </div>

          {/* الوصف */}
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              وصف العملية
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="مثال: تذكرة ذهاب وعودة - درجة سياحية"
              rows={2}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all resize-none"
            />
          </div>

          {/* ملاحظات */}
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              ملاحظات إضافية
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="أي تفاصيل إضافية..."
              rows={2}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all resize-none"
            />
          </div>
        </div>

        {/* زر الإرسال */}
        <button
          type="submit"
          className="w-full py-4 bg-gradient-to-l from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
        >
          <Plane className="w-5 h-5" />
          <span>تسجيل المعاملة</span>
        </button>
      </form>

      {/* نموذج إضافة عميل جديد */}
      {showCustomerForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">إضافة عميل جديد</h3>
              <button
                onClick={() => setShowCustomerForm(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  اسم العميل *
                </label>
                <input
                  type="text"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder="أدخل اسم العميل"
                  required
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  placeholder="01xxxxxxxxx"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  value={newCustomerEmail}
                  onChange={(e) => setNewCustomerEmail(e.target.value)}
                  placeholder="example@email.com"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم الجواز
                </label>
                <input
                  type="text"
                  value={newCustomerPassport}
                  onChange={(e) => setNewCustomerPassport(e.target.value)}
                  placeholder="A12345678"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-l from-green-600 to-green-700 text-white font-semibold rounded-xl hover:from-green-700 hover:to-green-800 transition-all shadow-lg hover:shadow-xl"
              >
                إضافة العميل
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
