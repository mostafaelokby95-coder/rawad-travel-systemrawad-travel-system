import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError } from "convex/values";

// إضافة عملية بيع تذكرة جديدة (فقط السعر ورقم الحجز إلزاميين)
export const create = mutation({
  args: {
    customerId: v.optional(v.id("customers")),
    customerName: v.optional(v.string()),
    ticketNumber: v.string(),
    destination: v.optional(v.string()),
    departureDate: v.optional(v.string()),
    returnDate: v.optional(v.string()),
    airline: v.optional(v.string()),
    amount: v.number(),
    commission: v.optional(v.number()),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    saleDate: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const user = await ctx.db.get(userId);
    if (!user) {
      throw new ConvexError("المستخدم غير موجود");
    }

    const saleId = await ctx.db.insert("sales", {
      customerId: args.customerId,
      customerName: args.customerName || "عميل غير محدد",
      ticketNumber: args.ticketNumber,
      destination: args.destination,
      departureDate: args.departureDate,
      returnDate: args.returnDate,
      airline: args.airline,
      amount: args.amount,
      commission: args.commission,
      description: args.description,
      notes: args.notes,
      saleDate: args.saleDate,
      employeeId: userId,
      employeeName: user.name || user.email || "موظف",
    });

    return saleId;
  },
});

// تعديل عملية بيع
export const update = mutation({
  args: {
    saleId: v.id("sales"),
    ticketNumber: v.optional(v.string()),
    destination: v.optional(v.string()),
    departureDate: v.optional(v.string()),
    returnDate: v.optional(v.string()),
    airline: v.optional(v.string()),
    amount: v.optional(v.number()),
    commission: v.optional(v.number()),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const sale = await ctx.db.get(args.saleId);
    if (!sale) {
      throw new ConvexError("عملية البيع غير موجودة");
    }

    // التحقق من الصلاحية
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";
    const isOwner = sale.employeeId === userId;

    if (!isAdmin && !isOwner) {
      throw new ConvexError("ليس لديك صلاحية لتعديل هذه العملية");
    }

    const updates: any = {};
    if (args.ticketNumber !== undefined) updates.ticketNumber = args.ticketNumber;
    if (args.destination !== undefined) updates.destination = args.destination;
    if (args.departureDate !== undefined) updates.departureDate = args.departureDate;
    if (args.returnDate !== undefined) updates.returnDate = args.returnDate;
    if (args.airline !== undefined) updates.airline = args.airline;
    if (args.amount !== undefined) updates.amount = args.amount;
    if (args.commission !== undefined) updates.commission = args.commission;
    if (args.description !== undefined) updates.description = args.description;
    if (args.notes !== undefined) updates.notes = args.notes;

    await ctx.db.patch(args.saleId, updates);

    return args.saleId;
  },
});

// حذف عملية بيع
export const remove = mutation({
  args: {
    saleId: v.id("sales"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const sale = await ctx.db.get(args.saleId);
    if (!sale) {
      throw new ConvexError("عملية البيع غير موجودة");
    }

    // التحقق من الصلاحية
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";
    const isOwner = sale.employeeId === userId;

    if (!isAdmin && !isOwner) {
      throw new ConvexError("ليس لديك صلاحية لحذف هذه العملية");
    }

    await ctx.db.delete(args.saleId);
    return true;
  },
});

// عرض جميع المبيعات (للمدير فقط)
export const listAll = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // التحقق من أن المستخدم Admin
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (userRole?.role !== "admin") {
      return [];
    }

    const sales = await ctx.db
      .query("sales")
      .order("desc")
      .collect();

    return sales;
  },
});

// عرض مبيعات الموظف الحالي فقط
export const listMySales = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const sales = await ctx.db
      .query("sales")
      .withIndex("by_employee", (q) => q.eq("employeeId", userId))
      .order("desc")
      .collect();

    return sales;
  },
});

// البحث في المبيعات
export const search = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // التحقق من دور المستخدم
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";

    // جلب المبيعات حسب الصلاحية
    let allSales;
    if (isAdmin) {
      allSales = await ctx.db.query("sales").collect();
    } else {
      allSales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", userId))
        .collect();
    }

    const searchLower = args.searchTerm.toLowerCase();
    return allSales.filter(sale => 
      sale.customerName.toLowerCase().includes(searchLower) ||
      (sale.ticketNumber && sale.ticketNumber.toLowerCase().includes(searchLower)) ||
      (sale.destination && sale.destination.toLowerCase().includes(searchLower)) ||
      (sale.airline && sale.airline.toLowerCase().includes(searchLower))
    );
  },
});

// إحصائيات المبيعات (للمدير - كل المبيعات، للموظف - مبيعاته فقط)
export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    // التحقق من دور المستخدم
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";

    // جلب المبيعات حسب الصلاحية
    let allSales;
    if (isAdmin) {
      allSales = await ctx.db.query("sales").collect();
    } else {
      allSales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", userId))
        .collect();
    }

    // إجمالي المبيعات
    const totalSales = allSales.reduce((sum, sale) => sum + sale.amount, 0);
    const totalCommission = allSales.reduce((sum, sale) => sum + (sale.commission || 0), 0);

    // عدد المبيعات
    const salesCount = allSales.length;

    // مبيعات اليوم
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayTimestamp = today.getTime();

    const todaySales = allSales.filter(sale => sale.saleDate >= todayTimestamp);
    const todayTotal = todaySales.reduce((sum, sale) => sum + sale.amount, 0);

    // مبيعات هذا الشهر
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthTimestamp = firstDayOfMonth.getTime();

    const monthSales = allSales.filter(sale => sale.saleDate >= monthTimestamp);
    const monthTotal = monthSales.reduce((sum, sale) => sum + sale.amount, 0);

    // أفضل الموظفين (للمدير فقط)
    let topEmployees: Array<{
      employeeId: string;
      employeeName: string;
      totalSales: number;
      salesCount: number;
    }> = [];
    if (isAdmin) {
      const employeeSales: Record<string, { name: string; total: number; count: number }> = {};
      
      allSales.forEach(sale => {
        if (!employeeSales[sale.employeeId]) {
          employeeSales[sale.employeeId] = {
            name: sale.employeeName,
            total: 0,
            count: 0,
          };
        }
        employeeSales[sale.employeeId].total += sale.amount;
        employeeSales[sale.employeeId].count += 1;
      });

      topEmployees = Object.entries(employeeSales)
        .map(([id, data]) => ({
          employeeId: id,
          employeeName: data.name,
          totalSales: data.total,
          salesCount: data.count,
        }))
        .sort((a, b) => b.totalSales - a.totalSales)
        .slice(0, 5);
    }

    return {
      totalSales,
      totalCommission,
      salesCount,
      todayTotal,
      todaySalesCount: todaySales.length,
      monthTotal,
      monthSalesCount: monthSales.length,
      topEmployees,
      isAdmin,
    };
  },
});

// مبيعات آخر 7 أيام
export const getLast7Days = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // التحقق من دور المستخدم
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";

    // جلب المبيعات حسب الصلاحية
    let allSales;
    if (isAdmin) {
      allSales = await ctx.db.query("sales").collect();
    } else {
      allSales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", userId))
        .collect();
    }

    const last7Days = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const nextDay = new Date(date);
      nextDay.setDate(nextDay.getDate() + 1);

      const daySales = allSales.filter(
        sale => sale.saleDate >= date.getTime() && sale.saleDate < nextDay.getTime()
      );

      const dayTotal = daySales.reduce((sum, sale) => sum + sale.amount, 0);

      last7Days.push({
        date: date.toLocaleDateString('ar-EG', { weekday: 'short', day: 'numeric', month: 'short' }),
        total: dayTotal,
        count: daySales.length,
      });
    }

    return last7Days;
  },
});

// مسح جميع المبيعات (للمدير فقط)
export const clearAllSales = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    // التحقق من أن المستخدم Admin
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (userRole?.role !== "admin") {
      throw new ConvexError("هذه العملية متاحة للمدير فقط");
    }

    // جلب جميع المبيعات
    const allSales = await ctx.db.query("sales").collect();

    // حذف كل عملية بيع
    for (const sale of allSales) {
      await ctx.db.delete(sale._id);
    }

    return { deletedCount: allSales.length };
  },
});
