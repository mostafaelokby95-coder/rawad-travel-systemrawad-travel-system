import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError } from "convex/values";

// تعيين دور للمستخدم (أول مستخدم يسجل يكون Admin)
export const assignRole = mutation({
  args: {
    role: v.union(v.literal("admin"), v.literal("employee")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    // التحقق من وجود دور سابق
    const existingRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existingRole) {
      throw new ConvexError("لديك دور بالفعل");
    }

    // إذا كان أول مستخدم، يصبح Admin
    const allRoles = await ctx.db.query("userRoles").collect();
    const role = allRoles.length === 0 ? "admin" : args.role;

    await ctx.db.insert("userRoles", {
      userId,
      role,
      createdAt: Date.now(),
    });

    return role;
  },
});

// الحصول على دور المستخدم الحالي
export const getMyRole = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return userRole?.role || null;
  },
});

// التحقق من أن المستخدم Admin
export const isAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return false;
    }

    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return userRole?.role === "admin";
  },
});
