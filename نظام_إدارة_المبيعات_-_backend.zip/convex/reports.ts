import { v } from "convex/values";
import { query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError } from "convex/values";

// تقرير مفصل حسب الفترة الزمنية
export const getDetailedReport = query({
  args: {
    startDate: v.number(),
    endDate: v.number(),
    employeeId: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    // التحقق من دور المستخدم
    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";

    // جلب المبيعات حسب الصلاحية والفترة
    let sales;
    if (args.employeeId && isAdmin) {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", args.employeeId!))
        .collect();
    } else if (isAdmin) {
      sales = await ctx.db.query("sales").collect();
    } else {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", userId))
        .collect();
    }

    // تصفية حسب الفترة
    const filteredSales = sales.filter(
      (sale) => sale.saleDate >= args.startDate && sale.saleDate <= args.endDate
    );

    // حساب الإحصائيات
    const totalSales = filteredSales.reduce((sum, sale) => sum + sale.amount, 0);
    const totalCommission = filteredSales.reduce((sum, sale) => sum + (sale.commission || 0), 0);
    const salesCount = filteredSales.length;
    const averageSale = salesCount > 0 ? totalSales / salesCount : 0;

    // تجميع حسب الوجهة
    const destinationStats: Record<string, { count: number; total: number }> = {};
    filteredSales.forEach((sale) => {
      const dest = sale.destination || "غير محدد";
      if (!destinationStats[dest]) {
        destinationStats[dest] = { count: 0, total: 0 };
      }
      destinationStats[dest].count += 1;
      destinationStats[dest].total += sale.amount;
    });

    // تجميع حسب شركة الطيران
    const airlineStats: Record<string, { count: number; total: number }> = {};
    filteredSales.forEach((sale) => {
      const airline = sale.airline || "غير محدد";
      if (!airlineStats[airline]) {
        airlineStats[airline] = { count: 0, total: 0 };
      }
      airlineStats[airline].count += 1;
      airlineStats[airline].total += sale.amount;
    });

    // أفضل الوجهات
    const topDestinations = Object.entries(destinationStats)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    // أفضل شركات الطيران
    const topAirlines = Object.entries(airlineStats)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    // المبيعات اليومية
    const dailySales: Record<string, { count: number; total: number }> = {};
    filteredSales.forEach((sale) => {
      const date = new Date(sale.saleDate).toLocaleDateString("ar-EG");
      if (!dailySales[date]) {
        dailySales[date] = { count: 0, total: 0 };
      }
      dailySales[date].count += 1;
      dailySales[date].total += sale.amount;
    });

    return {
      summary: {
        totalSales,
        totalCommission,
        salesCount,
        averageSale,
        period: {
          start: args.startDate,
          end: args.endDate,
        },
      },
      topDestinations,
      topAirlines,
      dailySales: Object.entries(dailySales)
        .map(([date, data]) => ({ date, ...data }))
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()),
      sales: filteredSales,
      isAdmin,
    };
  },
});

// مقارنة الأداء بين فترتين
export const comparePerformance = query({
  args: {
    period1Start: v.number(),
    period1End: v.number(),
    period2Start: v.number(),
    period2End: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const isAdmin = userRole?.role === "admin";

    let sales;
    if (isAdmin) {
      sales = await ctx.db.query("sales").collect();
    } else {
      sales = await ctx.db
        .query("sales")
        .withIndex("by_employee", (q) => q.eq("employeeId", userId))
        .collect();
    }

    // الفترة الأولى
    const period1Sales = sales.filter(
      (sale) => sale.saleDate >= args.period1Start && sale.saleDate <= args.period1End
    );
    const period1Total = period1Sales.reduce((sum, sale) => sum + sale.amount, 0);
    const period1Count = period1Sales.length;

    // الفترة الثانية
    const period2Sales = sales.filter(
      (sale) => sale.saleDate >= args.period2Start && sale.saleDate <= args.period2End
    );
    const period2Total = period2Sales.reduce((sum, sale) => sum + sale.amount, 0);
    const period2Count = period2Sales.length;

    // حساب النسب المئوية للتغيير
    const salesGrowth = period1Total > 0 ? ((period2Total - period1Total) / period1Total) * 100 : 0;
    const countGrowth = period1Count > 0 ? ((period2Count - period1Count) / period1Count) * 100 : 0;

    return {
      period1: {
        total: period1Total,
        count: period1Count,
        average: period1Count > 0 ? period1Total / period1Count : 0,
      },
      period2: {
        total: period2Total,
        count: period2Count,
        average: period2Count > 0 ? period2Total / period2Count : 0,
      },
      growth: {
        sales: salesGrowth,
        count: countGrowth,
      },
    };
  },
});

// تقرير أداء الموظفين (للمدير فقط)
export const getEmployeesPerformance = query({
  args: {
    startDate: v.number(),
    endDate: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const userRole = await ctx.db
      .query("userRoles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (userRole?.role !== "admin") {
      throw new ConvexError("هذا التقرير متاح للمدير فقط");
    }

    const sales = await ctx.db.query("sales").collect();
    const filteredSales = sales.filter(
      (sale) => sale.saleDate >= args.startDate && sale.saleDate <= args.endDate
    );

    // تجميع حسب الموظف
    const employeeStats: Record<
      string,
      { name: string; count: number; total: number; commission: number }
    > = {};

    filteredSales.forEach((sale) => {
      const empId = sale.employeeId;
      if (!employeeStats[empId]) {
        employeeStats[empId] = {
          name: sale.employeeName,
          count: 0,
          total: 0,
          commission: 0,
        };
      }
      employeeStats[empId].count += 1;
      employeeStats[empId].total += sale.amount;
      employeeStats[empId].commission += sale.commission || 0;
    });

    return Object.entries(employeeStats)
      .map(([id, data]) => ({
        employeeId: id,
        ...data,
        average: data.count > 0 ? data.total / data.count : 0,
      }))
      .sort((a, b) => b.total - a.total);
  },
});
