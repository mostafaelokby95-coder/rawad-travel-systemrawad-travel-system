import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  // جدول الأدوار والصلاحيات
  userRoles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("employee")),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  // جدول العملاء
  customers: defineTable({
    name: v.string(),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    passport: v.optional(v.string()),
    nationality: v.optional(v.string()),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
  }).index("by_created_by", ["createdBy"]),

  // جدول مبيعات التذاكر
  sales: defineTable({
    customerId: v.optional(v.id("customers")),
    customerName: v.string(),
    
    // تفاصيل التذكرة
    ticketNumber: v.optional(v.string()),
    destination: v.optional(v.string()),
    departureDate: v.optional(v.string()),
    returnDate: v.optional(v.string()),
    airline: v.optional(v.string()),
    
    // المبلغ
    amount: v.number(),
    commission: v.optional(v.number()),
    
    // الوصف والملاحظات
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    
    // التاريخ
    saleDate: v.number(),
    
    // الموظف
    employeeId: v.id("users"),
    employeeName: v.string(),
  })
    .index("by_employee", ["employeeId"])
    .index("by_date", ["saleDate"])
    .index("by_customer", ["customerId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
