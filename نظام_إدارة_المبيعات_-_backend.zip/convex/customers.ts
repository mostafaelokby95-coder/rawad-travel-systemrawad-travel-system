import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError } from "convex/values";

// إضافة عميل جديد
export const create = mutation({
  args: {
    name: v.string(),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    passport: v.optional(v.string()),
    nationality: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new ConvexError("يجب تسجيل الدخول أولاً");
    }

    const customerId = await ctx.db.insert("customers", {
      name: args.name,
      phone: args.phone,
      email: args.email,
      passport: args.passport,
      nationality: args.nationality,
      notes: args.notes,
      createdBy: userId,
    });

    return customerId;
  },
});

// عرض جميع العملاء
export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const customers = await ctx.db
      .query("customers")
      .order("desc")
      .collect();

    return customers;
  },
});

// البحث عن عميل
export const search = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const allCustomers = await ctx.db.query("customers").collect();
    
    const searchLower = args.searchTerm.toLowerCase();
    return allCustomers.filter(customer => 
      customer.name.toLowerCase().includes(searchLower) ||
      (customer.phone && customer.phone.includes(args.searchTerm)) ||
      (customer.passport && customer.passport.toLowerCase().includes(searchLower))
    );
  },
});
